class ChangeTitleApp
{
constructor() {
  this.btnGeneral="/html/body/div[2]/div/main/section/section/div[2]/a[1]";
  this.btnGeneralOld="/html/body/div[2]/div/nav[1]/section/div[1]/ul[3]/li[2]/a";                      
  this.btnExpand="/html/body/div[2]/div/main/section/div[2]/div[1]/section/div[1]/div[1]/button";
  this.btnExpandOld="/html/body/div[2]/div/main/section/div/section/div[2]/div[1]/div[2]/button";
  this.txtTitle="/html/body/div[2]/div/main/section/div[2]/div[1]/section/div[1]/div[2]/div/div/div/div[1]/input";
  this.txtTitleOld="/html/body/div[2]/div/main/section/div/section/div[2]/div[1]/div[1]/div[3]/div/div/div[1]/input";
  this.txtDescription="/html/body/div[2]/div/main/section/div[2]/div[1]/section/div[1]/div[2]/div/div/div/div[2]/input";
  this.txtDescriptionOld="/html/body/div[2]/div/main/section/div/section/div[2]/div[1]/div[1]/div[3]/div/div/div[2]/input";
  this.btnSave    ="/html/body/div[2]/div/main/section/div[1]/header/section/button";
  this.btnSaveOld ="/html/body/div[2]/div/main/section/div/header/section/button";

  this.txtTitleError="/html/body/div[2]/div/main/section/div[2]/div[1]/section/div[1]/div[2]/div/div/div/div[1]/p[1]";
  this.txtTitleMessageError="Title is too long";

  this.txtDescriptionError="/html/body/div[2]/div/main/section/div[2]/div[1]/section/div[1]/div[2]/div/div/div/div[2]/p[1]";
  this.txtDescriptionMessageError="Description is too long";
  
  

 }                       

}

module.exports = {
  ChangeTitleApp
  };
  