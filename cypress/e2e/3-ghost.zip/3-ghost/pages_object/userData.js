class UserData {
    constructor() {
    this.emailAdmin='nathanbelt23@gmail.com';
    this.passwordAdmin='YonathanBr1983*';
    this.passwordChange='YonathanBr1984*';
    }
    
    }
    module.exports = {
      UserData,
    };