class YourProfile {
constructor() {
this.txtNameYourProfile    = "/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[1]/input";
this.txtNameYourProfileOld = "/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[1]/input";
this.txtSlug='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[2]/input';
this.txtLocation='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[4]/input';
this.txtWebSite='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[5]/input';
this.txtFacebook='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[6]/input';
this.txtTwitter='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[7]/input';
this.txtArea='/html/body/div[2]/div/main/section/section/div/form[1]/div/fieldset/div[8]/textarea';
this.email='';
this.btnSaveYourProfile='/html/body/div[2]/div/main/section/div/header/section/button';
this.btnSaveYourProfileOld='/html/body/div[2]/div/main/section/header/section/button';
this.txtOldPassword='/html/body/div[2]/div/main/section/section/div/form[2]/div/fieldset/div[1]/input';
this.txtNewPasword= '/html/body/div[2]/div/main/section/section/div/form[2]/div/fieldset/div[2]/input';
this.txtVerifyPassword="/html/body/div[2]/div/main/section/section/div/form[2]/div/fieldset/div[3]/input";
this.btnChangePassword="/html/body/div[2]/div/main/section/section/div/form[2]/div/fieldset/div[4]/button"; 
this.btnCloseToad="/html/body/div[2]/div/aside/article/button";

this.nameMesaggeErrorIsLong="Name is too long";
this.bioMesaggeErrorIsLong="Bio is too long";
this.locationErrorIsLong="Location is too long";

}

}
module.exports = {
YourProfile
};
